import Questions from './Questions'
import Form from './Form'
import Result from './Result'
export {Form,Questions,Result}